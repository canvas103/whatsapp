(function () {



/* Exports */
Package._define("mobile-status-bar");

})();
