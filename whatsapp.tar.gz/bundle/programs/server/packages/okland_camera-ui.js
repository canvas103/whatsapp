(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MeteorCamera = Package['mdg:camera'].MeteorCamera;

/* Package-scope variables */
var MeteorCameraUI;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/okland_camera-ui/packages/okland_camera-ui.js                 //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/okland:camera-ui/camera-ui.js                            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
MeteorCameraUI = {};                                                 // 1
                                                                     // 2
                                                                     // 3
///////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("okland:camera-ui", {
  MeteorCameraUI: MeteorCameraUI
});

})();
