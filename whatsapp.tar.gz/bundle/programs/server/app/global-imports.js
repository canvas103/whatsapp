/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
ECMAScript = Package.ecmascript.ECMAScript;
LaunchScreen = Package['launch-screen'].LaunchScreen;
_ = Package.underscore._;
check = Package.check.check;
Match = Package.check.Match;
NpmModuleBcrypt = Package['npm-bcrypt'].NpmModuleBcrypt;
SMS = Package['mys:accounts-phone'].SMS;
enableDebugLogging = Package['reywood:publish-composite'].enableDebugLogging;
publishComposite = Package['reywood:publish-composite'].publishComposite;
MeteorCameraUI = Package['okland:camera-ui'].MeteorCameraUI;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
meteorInstall = Package.modules.meteorInstall;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
Autoupdate = Package.autoupdate.Autoupdate;

