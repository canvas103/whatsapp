var require = meteorInstall({"lib":{"collections.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/collections.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Chats: () => Chats,
  Messages: () => Messages
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Chats = new Mongo.Collection('chats');
const Messages = new Mongo.Collection('messages');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/methods.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 1);
let Chats, Messages;
module.watch(require("../lib/collections"), {
  Chats(v) {
    Chats = v;
  },

  Messages(v) {
    Messages = v;
  }

}, 2);
let HTTP;
module.watch(require("meteor/http"), {
  HTTP(v) {
    HTTP = v;
  }

}, 3);
let translate;
module.watch(require("google-translate-api"), {
  default(v) {
    translate = v;
  }

}, 4);
Meteor.methods({
  newMessage(message) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged in to send message.');
    }

    check(message, Match.OneOf({
      text: String,
      type: String,
      chatId: String
    }, {
      picture: String,
      type: String,
      chatId: String
    }));
    message.timestamp = new Date();
    message.userId = this.userId;
    const messageId = Messages.insert(message);
    Chats.update(message.chatId, {
      $set: {
        lastMessage: message
      }
    });
    const chat = Chats.findOne(message.chatId);
    const chatBot = Meteor.users.findOne({
      'profile.type': 'chatBot'
    });

    if (message.text && Meteor.isServer && _.include(chat.userIds, chatBot._id)) {
      console.log('isServer', Meteor.isServer);
      translate(message.text, {
        to: 'en'
      }).then(res => {
        console.log(res); // let s = {
        //     text: 'Hello there',
        //     from: {
        //         language: {didYouMean: false, iso: 'zh-CN'},
        //         text: {autoCorrected: true, value: '[你好]', didYouMean: false}
        //     },
        //     raw: ''
        // };

        const chatbotResponse = HTTP.call('GET', 'http://ec2-52-207-241-145.compute-1.amazonaws.com:8080/chat', {
          params: {
            sentence: res.text
          }
        });
        console.log(chatbotResponse);
        translate(chatbotResponse.content, {
          to: res.from.language.iso
        }).then(res => {
          let reMessage = {
            type: message.type,
            text: res.text,
            chatId: message.chatId,
            userId: chatBot._id
          };
          remoteMessage(reMessage);
        });
      }).catch(err => {
        console.error(err);
      });
    }

    return messageId;
  },

  updateName(name) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged in to update his name.');
    }

    check(name, String);

    if (name.length === 0) {
      throw Meteor.Error('name-required', 'Must provide a user name');
    }

    return Meteor.users.update(this.userId, {
      $set: {
        'profile.name': name
      }
    });
  },

  newChat(otherId) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged to create a chat.');
    }

    check(otherId, String);
    const otherUser = Meteor.users.findOne(otherId);

    if (!otherUser) {
      throw new Meteor.Error('user-not-exists', 'Chat\'s user not exists');
    }

    const chat = {
      userIds: [this.userId, otherId],
      createdAt: new Date()
    };
    const chatId = Chats.insert(chat);
    return chatId;
  },

  removeChat(chatId) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged to remove a chat.');
    }

    check(chatId, String);
    const chat = Chats.findOne(chatId);

    if (!chat || !_.include(chat.userIds, this.userId)) {
      throw new Meteor.Error('chat-not-exists', 'Chat not exists');
    }

    Messages.remove({
      chatId: chatId
    });
    return Chats.remove({
      _id: chatId
    });
  },

  updatePicture(data) {
    if (!this.userId) {
      throw new Meteor.Error('not-logged-in', 'Must be logged in to update his picture.');
    }

    check(data, String);
    return Meteor.users.update(this.userId, {
      $set: {
        'profile.picture': data
      }
    });
  }

});

function remoteMessage(message) {
  message.timestamp = new Date();
  const messageId = Messages.insert(message);
  Chats.update(message.chatId, {
    $set: {
      lastMessage: message
    }
  });
  return messageId;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"bootstrap.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/bootstrap.js                                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
Meteor.startup(() => {
  if (Meteor.users.find().count() !== 0) return;
  Accounts.createUserWithPhone({
    phone: '+972501234567',
    profile: {
      name: 'ChatBot',
      type: 'chatBot',
      picture: 'https://randomuser.me/api/portraits/thumb/lego/1.jpg'
    }
  });
  Accounts.createUserWithPhone({
    phone: '+972501234568',
    profile: {
      name: 'Ethan Gonzalez',
      picture: 'https://randomuser.me/api/portraits/thumb/men/1.jpg'
    }
  });
  Accounts.createUserWithPhone({
    phone: '+972501234569',
    profile: {
      name: 'Avery Stewart',
      picture: 'https://randomuser.me/api/portraits/thumb/women/1.jpg'
    }
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publications.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chats, Messages;
module.watch(require("../lib/collections"), {
  Chats(v) {
    Chats = v;
  },

  Messages(v) {
    Messages = v;
  }

}, 1);
Meteor.publish('users', function () {
  return Meteor.users.find({}, {
    fields: {
      profile: 1
    }
  });
});
Meteor.publishComposite('chats', function () {
  if (!this.userId) return;
  return {
    find() {
      return Chats.find({
        userIds: this.userId
      });
    },

    children: [{
      find(chat) {
        return Messages.find({
          chatId: chat._id
        });
      }

    }, {
      find(chat) {
        const query = {
          _id: {
            $in: chat.userIds
          }
        };
        const options = {
          fields: {
            profile: 1
          }
        };
        return Meteor.users.find(query, options);
      }

    }]
  };
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"sms.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/sms.js                                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
console.log('sms', SMS); // if (Meteor.settings && Meteor.settings.ACCOUNTS_PHONE) {
//     Accounts._options.adminPhoneNumbers = Meteor.settings.ACCOUNTS_PHONE.ADMIN_NUMBERS;
//
//     Accounts._options.phoneVerificationMasterCode = Meteor.settings.ACCOUNTS_PHONE.MASTER_CODE;
// }

SMS.twilio = {
  FROM: '+16312121062',
  ACCOUNT_SID: 'AC2113c40fcc3bf577b42fc3d12a5323f3',
  AUTH_TOKEN: '5376efa7519ab6963cad95ec126c1c31'
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {// code to run on server at startup
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/collections.js");
require("/lib/methods.js");
require("/server/bootstrap.js");
require("/server/publications.js");
require("/server/sms.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Jvb3RzdHJhcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Ntcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiQ2hhdHMiLCJNZXNzYWdlcyIsIk1vbmdvIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIkNvbGxlY3Rpb24iLCJNZXRlb3IiLCJjaGVjayIsIkhUVFAiLCJ0cmFuc2xhdGUiLCJkZWZhdWx0IiwibWV0aG9kcyIsIm5ld01lc3NhZ2UiLCJtZXNzYWdlIiwidXNlcklkIiwiRXJyb3IiLCJNYXRjaCIsIk9uZU9mIiwidGV4dCIsIlN0cmluZyIsInR5cGUiLCJjaGF0SWQiLCJwaWN0dXJlIiwidGltZXN0YW1wIiwiRGF0ZSIsIm1lc3NhZ2VJZCIsImluc2VydCIsInVwZGF0ZSIsIiRzZXQiLCJsYXN0TWVzc2FnZSIsImNoYXQiLCJmaW5kT25lIiwiY2hhdEJvdCIsInVzZXJzIiwiaXNTZXJ2ZXIiLCJfIiwiaW5jbHVkZSIsInVzZXJJZHMiLCJfaWQiLCJjb25zb2xlIiwibG9nIiwidG8iLCJ0aGVuIiwicmVzIiwiY2hhdGJvdFJlc3BvbnNlIiwiY2FsbCIsInBhcmFtcyIsInNlbnRlbmNlIiwiY29udGVudCIsImZyb20iLCJsYW5ndWFnZSIsImlzbyIsInJlTWVzc2FnZSIsInJlbW90ZU1lc3NhZ2UiLCJjYXRjaCIsImVyciIsImVycm9yIiwidXBkYXRlTmFtZSIsIm5hbWUiLCJsZW5ndGgiLCJuZXdDaGF0Iiwib3RoZXJJZCIsIm90aGVyVXNlciIsImNyZWF0ZWRBdCIsInJlbW92ZUNoYXQiLCJyZW1vdmUiLCJ1cGRhdGVQaWN0dXJlIiwiZGF0YSIsIkFjY291bnRzIiwic3RhcnR1cCIsImZpbmQiLCJjb3VudCIsImNyZWF0ZVVzZXJXaXRoUGhvbmUiLCJwaG9uZSIsInByb2ZpbGUiLCJwdWJsaXNoIiwiZmllbGRzIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwicXVlcnkiLCIkaW4iLCJvcHRpb25zIiwiU01TIiwidHdpbGlvIiwiRlJPTSIsIkFDQ09VTlRfU0lEIiwiQVVUSF9UT0tFTiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFNBQU0sTUFBSUEsS0FBWDtBQUFpQkMsWUFBUyxNQUFJQTtBQUE5QixDQUFkO0FBQXVELElBQUlDLEtBQUo7QUFBVUosT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDRixRQUFNRyxDQUFOLEVBQVE7QUFBQ0gsWUFBTUcsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUUxRCxNQUFNTCxRQUFRLElBQUlFLE1BQU1JLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1MLFdBQVcsSUFBSUMsTUFBTUksVUFBVixDQUFxQixVQUFyQixDQUFqQixDOzs7Ozs7Ozs7OztBQ0hQLElBQUlDLE1BQUo7QUFBV1QsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRyxTQUFPRixDQUFQLEVBQVM7QUFBQ0UsYUFBT0YsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRyxLQUFKO0FBQVVWLE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksUUFBTUgsQ0FBTixFQUFRO0FBQUNHLFlBQU1ILENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUwsS0FBSixFQUFVQyxRQUFWO0FBQW1CSCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDSixRQUFNSyxDQUFOLEVBQVE7QUFBQ0wsWUFBTUssQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkosV0FBU0ksQ0FBVCxFQUFXO0FBQUNKLGVBQVNJLENBQVQ7QUFBVzs7QUFBMUMsQ0FBM0MsRUFBdUYsQ0FBdkY7QUFBMEYsSUFBSUksSUFBSjtBQUFTWCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNLLE9BQUtKLENBQUwsRUFBTztBQUFDSSxXQUFLSixDQUFMO0FBQU87O0FBQWhCLENBQXBDLEVBQXNELENBQXREO0FBQXlELElBQUlLLFNBQUo7QUFBY1osT0FBT0ssS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQ08sVUFBUU4sQ0FBUixFQUFVO0FBQUNLLGdCQUFVTCxDQUFWO0FBQVk7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFO0FBTTdVRSxPQUFPSyxPQUFQLENBQWU7QUFDWEMsYUFBV0MsT0FBWCxFQUFvQjtBQUNoQixRQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVIsT0FBT1MsS0FBWCxDQUFpQixlQUFqQixFQUNGLG9DQURFLENBQU47QUFFSDs7QUFFRFIsVUFBTU0sT0FBTixFQUFlRyxNQUFNQyxLQUFOLENBQ1g7QUFDSUMsWUFBTUMsTUFEVjtBQUVJQyxZQUFNRCxNQUZWO0FBR0lFLGNBQVFGO0FBSFosS0FEVyxFQU1YO0FBQ0lHLGVBQVNILE1BRGI7QUFFSUMsWUFBTUQsTUFGVjtBQUdJRSxjQUFRRjtBQUhaLEtBTlcsQ0FBZjtBQWFBTixZQUFRVSxTQUFSLEdBQW9CLElBQUlDLElBQUosRUFBcEI7QUFDQVgsWUFBUUMsTUFBUixHQUFpQixLQUFLQSxNQUF0QjtBQUVBLFVBQU1XLFlBQVl6QixTQUFTMEIsTUFBVCxDQUFnQmIsT0FBaEIsQ0FBbEI7QUFDQWQsVUFBTTRCLE1BQU4sQ0FBYWQsUUFBUVEsTUFBckIsRUFBNkI7QUFBQ08sWUFBTTtBQUFDQyxxQkFBYWhCO0FBQWQ7QUFBUCxLQUE3QjtBQUNBLFVBQU1pQixPQUFPL0IsTUFBTWdDLE9BQU4sQ0FBY2xCLFFBQVFRLE1BQXRCLENBQWI7QUFDQSxVQUFNVyxVQUFVMUIsT0FBTzJCLEtBQVAsQ0FBYUYsT0FBYixDQUFxQjtBQUFDLHNCQUFnQjtBQUFqQixLQUFyQixDQUFoQjs7QUFHQSxRQUFJbEIsUUFBUUssSUFBUixJQUFnQlosT0FBTzRCLFFBQXZCLElBQW1DQyxFQUFFQyxPQUFGLENBQVVOLEtBQUtPLE9BQWYsRUFBd0JMLFFBQVFNLEdBQWhDLENBQXZDLEVBQTZFO0FBQ3pFQyxjQUFRQyxHQUFSLENBQVksVUFBWixFQUF3QmxDLE9BQU80QixRQUEvQjtBQUVBekIsZ0JBQVVJLFFBQVFLLElBQWxCLEVBQXdCO0FBQUN1QixZQUFJO0FBQUwsT0FBeEIsRUFDS0MsSUFETCxDQUNVQyxPQUFPO0FBQ1RKLGdCQUFRQyxHQUFSLENBQVlHLEdBQVosRUFEUyxDQUVUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsY0FBTUMsa0JBQWtCcEMsS0FBS3FDLElBQUwsQ0FBVSxLQUFWLEVBQWlCLDZEQUFqQixFQUFnRjtBQUNwR0Msa0JBQVE7QUFBQ0Msc0JBQVVKLElBQUl6QjtBQUFmO0FBRDRGLFNBQWhGLENBQXhCO0FBR0FxQixnQkFBUUMsR0FBUixDQUFZSSxlQUFaO0FBQ0FuQyxrQkFBVW1DLGdCQUFnQkksT0FBMUIsRUFBbUM7QUFBQ1AsY0FBSUUsSUFBSU0sSUFBSixDQUFTQyxRQUFULENBQWtCQztBQUF2QixTQUFuQyxFQUNLVCxJQURMLENBQ1VDLE9BQU87QUFDVCxjQUFJUyxZQUFZO0FBQ1poQyxrQkFBTVAsUUFBUU8sSUFERjtBQUVaRixrQkFBTXlCLElBQUl6QixJQUZFO0FBR1pHLG9CQUFRUixRQUFRUSxNQUhKO0FBSVpQLG9CQUFRa0IsUUFBUU07QUFKSixXQUFoQjtBQU1BZSx3QkFBY0QsU0FBZDtBQUNILFNBVEw7QUFVSCxPQTFCTCxFQTJCS0UsS0EzQkwsQ0EyQldDLE9BQU87QUFDVmhCLGdCQUFRaUIsS0FBUixDQUFjRCxHQUFkO0FBQ0gsT0E3Qkw7QUE4Qkg7O0FBRUQsV0FBTzlCLFNBQVA7QUFDSCxHQWpFVTs7QUFtRVhnQyxhQUFXQyxJQUFYLEVBQWlCO0FBQ2IsUUFBSSxDQUFDLEtBQUs1QyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJUixPQUFPUyxLQUFYLENBQWlCLGVBQWpCLEVBQ0YsdUNBREUsQ0FBTjtBQUVIOztBQUVEUixVQUFNbUQsSUFBTixFQUFZdkMsTUFBWjs7QUFFQSxRQUFJdUMsS0FBS0MsTUFBTCxLQUFnQixDQUFwQixFQUF1QjtBQUNuQixZQUFNckQsT0FBT1MsS0FBUCxDQUFhLGVBQWIsRUFBOEIsMEJBQTlCLENBQU47QUFDSDs7QUFFRCxXQUFPVCxPQUFPMkIsS0FBUCxDQUFhTixNQUFiLENBQW9CLEtBQUtiLE1BQXpCLEVBQWlDO0FBQUNjLFlBQU07QUFBQyx3QkFBZ0I4QjtBQUFqQjtBQUFQLEtBQWpDLENBQVA7QUFDSCxHQWhGVTs7QUFrRlhFLFVBQVFDLE9BQVIsRUFBaUI7QUFDYixRQUFJLENBQUMsS0FBSy9DLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlSLE9BQU9TLEtBQVgsQ0FBaUIsZUFBakIsRUFDRixrQ0FERSxDQUFOO0FBRUg7O0FBRURSLFVBQU1zRCxPQUFOLEVBQWUxQyxNQUFmO0FBQ0EsVUFBTTJDLFlBQVl4RCxPQUFPMkIsS0FBUCxDQUFhRixPQUFiLENBQXFCOEIsT0FBckIsQ0FBbEI7O0FBRUEsUUFBSSxDQUFDQyxTQUFMLEVBQWdCO0FBQ1osWUFBTSxJQUFJeEQsT0FBT1MsS0FBWCxDQUFpQixpQkFBakIsRUFDRix5QkFERSxDQUFOO0FBRUg7O0FBRUQsVUFBTWUsT0FBTztBQUNUTyxlQUFTLENBQUMsS0FBS3ZCLE1BQU4sRUFBYytDLE9BQWQsQ0FEQTtBQUVURSxpQkFBVyxJQUFJdkMsSUFBSjtBQUZGLEtBQWI7QUFLQSxVQUFNSCxTQUFTdEIsTUFBTTJCLE1BQU4sQ0FBYUksSUFBYixDQUFmO0FBRUEsV0FBT1QsTUFBUDtBQUNILEdBeEdVOztBQTBHWDJDLGFBQVczQyxNQUFYLEVBQW1CO0FBQ2YsUUFBSSxDQUFDLEtBQUtQLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlSLE9BQU9TLEtBQVgsQ0FBaUIsZUFBakIsRUFDRixrQ0FERSxDQUFOO0FBRUg7O0FBRURSLFVBQU1jLE1BQU4sRUFBY0YsTUFBZDtBQUVBLFVBQU1XLE9BQU8vQixNQUFNZ0MsT0FBTixDQUFjVixNQUFkLENBQWI7O0FBRUEsUUFBSSxDQUFDUyxJQUFELElBQVMsQ0FBQ0ssRUFBRUMsT0FBRixDQUFVTixLQUFLTyxPQUFmLEVBQXdCLEtBQUt2QixNQUE3QixDQUFkLEVBQW9EO0FBQ2hELFlBQU0sSUFBSVIsT0FBT1MsS0FBWCxDQUFpQixpQkFBakIsRUFDRixpQkFERSxDQUFOO0FBRUg7O0FBRURmLGFBQVNpRSxNQUFULENBQWdCO0FBQUM1QyxjQUFRQTtBQUFULEtBQWhCO0FBRUEsV0FBT3RCLE1BQU1rRSxNQUFOLENBQWE7QUFBQzNCLFdBQUtqQjtBQUFOLEtBQWIsQ0FBUDtBQUNILEdBNUhVOztBQThIWDZDLGdCQUFjQyxJQUFkLEVBQW9CO0FBQ2hCLFFBQUksQ0FBQyxLQUFLckQsTUFBVixFQUFrQjtBQUNkLFlBQU0sSUFBSVIsT0FBT1MsS0FBWCxDQUFpQixlQUFqQixFQUNGLDBDQURFLENBQU47QUFFSDs7QUFFRFIsVUFBTTRELElBQU4sRUFBWWhELE1BQVo7QUFFQSxXQUFPYixPQUFPMkIsS0FBUCxDQUFhTixNQUFiLENBQW9CLEtBQUtiLE1BQXpCLEVBQWlDO0FBQUNjLFlBQU07QUFBQywyQkFBbUJ1QztBQUFwQjtBQUFQLEtBQWpDLENBQVA7QUFDSDs7QUF2SVUsQ0FBZjs7QUEwSUEsU0FBU2QsYUFBVCxDQUF1QnhDLE9BQXZCLEVBQWdDO0FBRTVCQSxVQUFRVSxTQUFSLEdBQW9CLElBQUlDLElBQUosRUFBcEI7QUFDQSxRQUFNQyxZQUFZekIsU0FBUzBCLE1BQVQsQ0FBZ0JiLE9BQWhCLENBQWxCO0FBQ0FkLFFBQU00QixNQUFOLENBQWFkLFFBQVFRLE1BQXJCLEVBQTZCO0FBQUNPLFVBQU07QUFBQ0MsbUJBQWFoQjtBQUFkO0FBQVAsR0FBN0I7QUFFQSxTQUFPWSxTQUFQO0FBRUgsQzs7Ozs7Ozs7Ozs7QUN4SkQsSUFBSW5CLE1BQUo7QUFBV1QsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRyxTQUFPRixDQUFQLEVBQVM7QUFBQ0UsYUFBT0YsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJZ0UsUUFBSjtBQUFhdkUsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQ2lFLFdBQVNoRSxDQUFULEVBQVc7QUFBQ2dFLGVBQVNoRSxDQUFUO0FBQVc7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFO0FBR3ZGRSxPQUFPK0QsT0FBUCxDQUFlLE1BQU07QUFDakIsTUFBSS9ELE9BQU8yQixLQUFQLENBQWFxQyxJQUFiLEdBQW9CQyxLQUFwQixPQUFnQyxDQUFwQyxFQUF1QztBQUV2Q0gsV0FBU0ksbUJBQVQsQ0FBNkI7QUFDekJDLFdBQU8sZUFEa0I7QUFFekJDLGFBQVM7QUFDTGhCLFlBQU0sU0FERDtBQUVMdEMsWUFBTSxTQUZEO0FBR0xFLGVBQVM7QUFISjtBQUZnQixHQUE3QjtBQVNBOEMsV0FBU0ksbUJBQVQsQ0FBNkI7QUFDekJDLFdBQU8sZUFEa0I7QUFFekJDLGFBQVM7QUFDTGhCLFlBQU0sZ0JBREQ7QUFFTHBDLGVBQVM7QUFGSjtBQUZnQixHQUE3QjtBQVFBOEMsV0FBU0ksbUJBQVQsQ0FBNkI7QUFDekJDLFdBQU8sZUFEa0I7QUFFekJDLGFBQVM7QUFDTGhCLFlBQU0sZUFERDtBQUVMcEMsZUFBUztBQUZKO0FBRmdCLEdBQTdCO0FBUUgsQ0E1QkQsRTs7Ozs7Ozs7Ozs7QUNIQSxJQUFJaEIsTUFBSjtBQUFXVCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNHLFNBQU9GLENBQVAsRUFBUztBQUFDRSxhQUFPRixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlMLEtBQUosRUFBVUMsUUFBVjtBQUFtQkgsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0osUUFBTUssQ0FBTixFQUFRO0FBQUNMLFlBQU1LLENBQU47QUFBUSxHQUFsQjs7QUFBbUJKLFdBQVNJLENBQVQsRUFBVztBQUFDSixlQUFTSSxDQUFUO0FBQVc7O0FBQTFDLENBQTNDLEVBQXVGLENBQXZGO0FBRzdGRSxPQUFPcUUsT0FBUCxDQUFlLE9BQWYsRUFBd0IsWUFBWTtBQUNoQyxTQUFPckUsT0FBTzJCLEtBQVAsQ0FBYXFDLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0I7QUFBQ00sWUFBUTtBQUFDRixlQUFTO0FBQVY7QUFBVCxHQUF0QixDQUFQO0FBQ0gsQ0FGRDtBQUlBcEUsT0FBT3VFLGdCQUFQLENBQXdCLE9BQXhCLEVBQWlDLFlBQVc7QUFDeEMsTUFBSSxDQUFDLEtBQUsvRCxNQUFWLEVBQWtCO0FBRWxCLFNBQU87QUFDSHdELFdBQU87QUFDSCxhQUFPdkUsTUFBTXVFLElBQU4sQ0FBVztBQUFFakMsaUJBQVMsS0FBS3ZCO0FBQWhCLE9BQVgsQ0FBUDtBQUNILEtBSEU7O0FBSUhnRSxjQUFVLENBQ047QUFDSVIsV0FBS3hDLElBQUwsRUFBVztBQUNQLGVBQU85QixTQUFTc0UsSUFBVCxDQUFjO0FBQUVqRCxrQkFBUVMsS0FBS1E7QUFBZixTQUFkLENBQVA7QUFDSDs7QUFITCxLQURNLEVBTU47QUFDSWdDLFdBQUt4QyxJQUFMLEVBQVc7QUFDUCxjQUFNaUQsUUFBUTtBQUFFekMsZUFBSztBQUFFMEMsaUJBQUtsRCxLQUFLTztBQUFaO0FBQVAsU0FBZDtBQUNBLGNBQU00QyxVQUFVO0FBQUVMLGtCQUFRO0FBQUVGLHFCQUFTO0FBQVg7QUFBVixTQUFoQjtBQUVBLGVBQU9wRSxPQUFPMkIsS0FBUCxDQUFhcUMsSUFBYixDQUFrQlMsS0FBbEIsRUFBeUJFLE9BQXpCLENBQVA7QUFDSDs7QUFOTCxLQU5NO0FBSlAsR0FBUDtBQW9CSCxDQXZCRCxFOzs7Ozs7Ozs7OztBQ1BBLElBQUkzRSxNQUFKO0FBQVdULE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0csU0FBT0YsQ0FBUCxFQUFTO0FBQUNFLGFBQU9GLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWdFLFFBQUo7QUFBYXZFLE9BQU9LLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNpRSxXQUFTaEUsQ0FBVCxFQUFXO0FBQUNnRSxlQUFTaEUsQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUV2Rm1DLFFBQVFDLEdBQVIsQ0FBWSxLQUFaLEVBQWtCMEMsR0FBbEIsRSxDQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FBLElBQUlDLE1BQUosR0FBYTtBQUFDQyxRQUFNLGNBQVA7QUFBdUJDLGVBQWEsb0NBQXBDO0FBQTBFQyxjQUFZO0FBQXRGLENBQWIsQzs7Ozs7Ozs7Ozs7QUNUQSxJQUFJaEYsTUFBSjtBQUFXVCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNHLFNBQU9GLENBQVAsRUFBUztBQUFDRSxhQUFPRixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRVhFLE9BQU8rRCxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgQ2hhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhdHMnKTtcbmV4cG9ydCBjb25zdCBNZXNzYWdlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtZXNzYWdlcycpO1xuIiwiaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHtjaGVja30gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7Q2hhdHMsIE1lc3NhZ2VzfSBmcm9tICcuLi9saWIvY29sbGVjdGlvbnMnO1xuaW1wb3J0IHtIVFRQfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgdHJhbnNsYXRlIGZyb20gJ2dvb2dsZS10cmFuc2xhdGUtYXBpJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgIG5ld01lc3NhZ2UobWVzc2FnZSkge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJyxcbiAgICAgICAgICAgICAgICAnTXVzdCBiZSBsb2dnZWQgaW4gdG8gc2VuZCBtZXNzYWdlLicpO1xuICAgICAgICB9XG5cbiAgICAgICAgY2hlY2sobWVzc2FnZSwgTWF0Y2guT25lT2YoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGV4dDogU3RyaW5nLFxuICAgICAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgICAgICBjaGF0SWQ6IFN0cmluZ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwaWN0dXJlOiBTdHJpbmcsXG4gICAgICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgICAgICAgIGNoYXRJZDogU3RyaW5nXG4gICAgICAgICAgICB9XG4gICAgICAgICkpO1xuXG4gICAgICAgIG1lc3NhZ2UudGltZXN0YW1wID0gbmV3IERhdGUoKTtcbiAgICAgICAgbWVzc2FnZS51c2VySWQgPSB0aGlzLnVzZXJJZDtcblxuICAgICAgICBjb25zdCBtZXNzYWdlSWQgPSBNZXNzYWdlcy5pbnNlcnQobWVzc2FnZSk7XG4gICAgICAgIENoYXRzLnVwZGF0ZShtZXNzYWdlLmNoYXRJZCwgeyRzZXQ6IHtsYXN0TWVzc2FnZTogbWVzc2FnZX19KTtcbiAgICAgICAgY29uc3QgY2hhdCA9IENoYXRzLmZpbmRPbmUobWVzc2FnZS5jaGF0SWQpO1xuICAgICAgICBjb25zdCBjaGF0Qm90ID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeydwcm9maWxlLnR5cGUnOiAnY2hhdEJvdCd9KTtcblxuXG4gICAgICAgIGlmIChtZXNzYWdlLnRleHQgJiYgTWV0ZW9yLmlzU2VydmVyICYmIF8uaW5jbHVkZShjaGF0LnVzZXJJZHMsIGNoYXRCb3QuX2lkKSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ2lzU2VydmVyJywgTWV0ZW9yLmlzU2VydmVyKTtcblxuICAgICAgICAgICAgdHJhbnNsYXRlKG1lc3NhZ2UudGV4dCwge3RvOiAnZW4nfSlcbiAgICAgICAgICAgICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMpO1xuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHRleHQ6ICdIZWxsbyB0aGVyZScsXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICBmcm9tOiB7XG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgbGFuZ3VhZ2U6IHtkaWRZb3VNZWFuOiBmYWxzZSwgaXNvOiAnemgtQ04nfSxcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICB0ZXh0OiB7YXV0b0NvcnJlY3RlZDogdHJ1ZSwgdmFsdWU6ICdb5L2g5aW9XScsIGRpZFlvdU1lYW46IGZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHJhdzogJydcbiAgICAgICAgICAgICAgICAgICAgLy8gfTtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGF0Ym90UmVzcG9uc2UgPSBIVFRQLmNhbGwoJ0dFVCcsICdodHRwOi8vZWMyLTUyLTIwNy0yNDEtMTQ1LmNvbXB1dGUtMS5hbWF6b25hd3MuY29tOjgwODAvY2hhdCcsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtczoge3NlbnRlbmNlOiByZXMudGV4dH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGNoYXRib3RSZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zbGF0ZShjaGF0Ym90UmVzcG9uc2UuY29udGVudCwge3RvOiByZXMuZnJvbS5sYW5ndWFnZS5pc299KVxuICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVNZXNzYWdlID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBtZXNzYWdlLnR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IHJlcy50ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGF0SWQ6IG1lc3NhZ2UuY2hhdElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IGNoYXRCb3QuX2lkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3RlTWVzc2FnZShyZU1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG1lc3NhZ2VJZDtcbiAgICB9LFxuXG4gICAgdXBkYXRlTmFtZShuYW1lKSB7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdC1sb2dnZWQtaW4nLFxuICAgICAgICAgICAgICAgICdNdXN0IGJlIGxvZ2dlZCBpbiB0byB1cGRhdGUgaGlzIG5hbWUuJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjaGVjayhuYW1lLCBTdHJpbmcpO1xuXG4gICAgICAgIGlmIChuYW1lLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgTWV0ZW9yLkVycm9yKCduYW1lLXJlcXVpcmVkJywgJ011c3QgcHJvdmlkZSBhIHVzZXIgbmFtZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy51cGRhdGUodGhpcy51c2VySWQsIHskc2V0OiB7J3Byb2ZpbGUubmFtZSc6IG5hbWV9fSk7XG4gICAgfVxuICAgICxcbiAgICBuZXdDaGF0KG90aGVySWQpIHtcbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsXG4gICAgICAgICAgICAgICAgJ011c3QgYmUgbG9nZ2VkIHRvIGNyZWF0ZSBhIGNoYXQuJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjaGVjayhvdGhlcklkLCBTdHJpbmcpO1xuICAgICAgICBjb25zdCBvdGhlclVzZXIgPSBNZXRlb3IudXNlcnMuZmluZE9uZShvdGhlcklkKTtcblxuICAgICAgICBpZiAoIW90aGVyVXNlcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcigndXNlci1ub3QtZXhpc3RzJyxcbiAgICAgICAgICAgICAgICAnQ2hhdFxcJ3MgdXNlciBub3QgZXhpc3RzJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjaGF0ID0ge1xuICAgICAgICAgICAgdXNlcklkczogW3RoaXMudXNlcklkLCBvdGhlcklkXSxcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKVxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGNoYXRJZCA9IENoYXRzLmluc2VydChjaGF0KTtcblxuICAgICAgICByZXR1cm4gY2hhdElkO1xuICAgIH1cbiAgICAsXG4gICAgcmVtb3ZlQ2hhdChjaGF0SWQpIHtcbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWxvZ2dlZC1pbicsXG4gICAgICAgICAgICAgICAgJ011c3QgYmUgbG9nZ2VkIHRvIHJlbW92ZSBhIGNoYXQuJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjaGVjayhjaGF0SWQsIFN0cmluZyk7XG5cbiAgICAgICAgY29uc3QgY2hhdCA9IENoYXRzLmZpbmRPbmUoY2hhdElkKTtcblxuICAgICAgICBpZiAoIWNoYXQgfHwgIV8uaW5jbHVkZShjaGF0LnVzZXJJZHMsIHRoaXMudXNlcklkKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignY2hhdC1ub3QtZXhpc3RzJyxcbiAgICAgICAgICAgICAgICAnQ2hhdCBub3QgZXhpc3RzJyk7XG4gICAgICAgIH1cblxuICAgICAgICBNZXNzYWdlcy5yZW1vdmUoe2NoYXRJZDogY2hhdElkfSk7XG5cbiAgICAgICAgcmV0dXJuIENoYXRzLnJlbW92ZSh7X2lkOiBjaGF0SWR9KTtcbiAgICB9XG4gICAgLFxuICAgIHVwZGF0ZVBpY3R1cmUoZGF0YSkge1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtbG9nZ2VkLWluJyxcbiAgICAgICAgICAgICAgICAnTXVzdCBiZSBsb2dnZWQgaW4gdG8gdXBkYXRlIGhpcyBwaWN0dXJlLicpO1xuICAgICAgICB9XG5cbiAgICAgICAgY2hlY2soZGF0YSwgU3RyaW5nKTtcblxuICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLnVwZGF0ZSh0aGlzLnVzZXJJZCwgeyRzZXQ6IHsncHJvZmlsZS5waWN0dXJlJzogZGF0YX19KTtcbiAgICB9XG59KTtcblxuZnVuY3Rpb24gcmVtb3RlTWVzc2FnZShtZXNzYWdlKSB7XG5cbiAgICBtZXNzYWdlLnRpbWVzdGFtcCA9IG5ldyBEYXRlKCk7XG4gICAgY29uc3QgbWVzc2FnZUlkID0gTWVzc2FnZXMuaW5zZXJ0KG1lc3NhZ2UpO1xuICAgIENoYXRzLnVwZGF0ZShtZXNzYWdlLmNoYXRJZCwgeyRzZXQ6IHtsYXN0TWVzc2FnZTogbWVzc2FnZX19KTtcblxuICAgIHJldHVybiBtZXNzYWdlSWQ7XG5cbn0iLCJpbXBvcnQge01ldGVvcn0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7QWNjb3VudHN9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgIGlmIChNZXRlb3IudXNlcnMuZmluZCgpLmNvdW50KCkgIT09IDApIHJldHVybjtcblxuICAgIEFjY291bnRzLmNyZWF0ZVVzZXJXaXRoUGhvbmUoe1xuICAgICAgICBwaG9uZTogJys5NzI1MDEyMzQ1NjcnLFxuICAgICAgICBwcm9maWxlOiB7XG4gICAgICAgICAgICBuYW1lOiAnQ2hhdEJvdCcsXG4gICAgICAgICAgICB0eXBlOiAnY2hhdEJvdCcsXG4gICAgICAgICAgICBwaWN0dXJlOiAnaHR0cHM6Ly9yYW5kb211c2VyLm1lL2FwaS9wb3J0cmFpdHMvdGh1bWIvbGVnby8xLmpwZydcbiAgICAgICAgfSxcbiAgICB9KTtcblxuICAgIEFjY291bnRzLmNyZWF0ZVVzZXJXaXRoUGhvbmUoe1xuICAgICAgICBwaG9uZTogJys5NzI1MDEyMzQ1NjgnLFxuICAgICAgICBwcm9maWxlOiB7XG4gICAgICAgICAgICBuYW1lOiAnRXRoYW4gR29uemFsZXonLFxuICAgICAgICAgICAgcGljdHVyZTogJ2h0dHBzOi8vcmFuZG9tdXNlci5tZS9hcGkvcG9ydHJhaXRzL3RodW1iL21lbi8xLmpwZydcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgQWNjb3VudHMuY3JlYXRlVXNlcldpdGhQaG9uZSh7XG4gICAgICAgIHBob25lOiAnKzk3MjUwMTIzNDU2OScsXG4gICAgICAgIHByb2ZpbGU6IHtcbiAgICAgICAgICAgIG5hbWU6ICdBdmVyeSBTdGV3YXJ0JyxcbiAgICAgICAgICAgIHBpY3R1cmU6ICdodHRwczovL3JhbmRvbXVzZXIubWUvYXBpL3BvcnRyYWl0cy90aHVtYi93b21lbi8xLmpwZydcbiAgICAgICAgfVxuICAgIH0pO1xuXG59KTtcbiIsImltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENoYXRzLCBNZXNzYWdlcyB9IGZyb20gJy4uL2xpYi9jb2xsZWN0aW9ucyc7XG5cbk1ldGVvci5wdWJsaXNoKCd1c2VycycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoe30sIHtmaWVsZHM6IHtwcm9maWxlOiAxfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoQ29tcG9zaXRlKCdjaGF0cycsIGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy51c2VySWQpIHJldHVybjtcblxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKSB7XG4gICAgICAgICAgICByZXR1cm4gQ2hhdHMuZmluZCh7IHVzZXJJZHM6IHRoaXMudXNlcklkIH0pO1xuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoY2hhdCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTWVzc2FnZXMuZmluZCh7IGNoYXRJZDogY2hhdC5faWQgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGNoYXQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVlcnkgPSB7IF9pZDogeyAkaW46IGNoYXQudXNlcklkcyB9IH07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7IGZpZWxkczogeyBwcm9maWxlOiAxIH0gfTtcblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQocXVlcnksIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH07XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnO1xuY29uc29sZS5sb2coJ3NtcycsU01TKTtcblxuLy8gaWYgKE1ldGVvci5zZXR0aW5ncyAmJiBNZXRlb3Iuc2V0dGluZ3MuQUNDT1VOVFNfUEhPTkUpIHtcbi8vICAgICBBY2NvdW50cy5fb3B0aW9ucy5hZG1pblBob25lTnVtYmVycyA9IE1ldGVvci5zZXR0aW5ncy5BQ0NPVU5UU19QSE9ORS5BRE1JTl9OVU1CRVJTO1xuLy9cbi8vICAgICBBY2NvdW50cy5fb3B0aW9ucy5waG9uZVZlcmlmaWNhdGlvbk1hc3RlckNvZGUgPSBNZXRlb3Iuc2V0dGluZ3MuQUNDT1VOVFNfUEhPTkUuTUFTVEVSX0NPREU7XG4vLyB9XG5TTVMudHdpbGlvID0ge0ZST006ICcrMTYzMTIxMjEwNjInLCBBQ0NPVU5UX1NJRDogJ0FDMjExM2M0MGZjYzNiZjU3N2I0MmZjM2QxMmE1MzIzZjMnLCBBVVRIX1RPS0VOOiAnNTM3NmVmYTc1MTlhYjY5NjNjYWQ5NWVjMTI2YzFjMzEnfTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiJdfQ==
